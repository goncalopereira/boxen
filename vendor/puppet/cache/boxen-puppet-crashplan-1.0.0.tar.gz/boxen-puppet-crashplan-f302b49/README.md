# Crashplan Puppet Module for Boxen

Install [Crashplan](http://www.crashplan.com/) on your Mac.

## Usage

```puppet
include Crashplan
```

## Required Puppet Modules

* `boxen`
